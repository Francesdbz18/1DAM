package tareaclase;

import java.time.LocalDate;

import javax.swing.JOptionPane;

public class Profesor extends Persona {

    private String cuentaBancaria;
    private double nomina;

    /**
     * Constructor vacío para Profesor.
     */
    public Profesor() {

    }

    /**
     * Constructor de Profesor.
     * @param nombre
     * @param dni
     * @param cuentaBancaria
     * @param nomina
     * @param fechaNacimiento
     * @throws Exception
     */
    public Profesor(String nombre, String dni, String cuentaBancaria, double nomina, LocalDate fechaNacimiento) throws Exception {
        super(nombre, dni, fechaNacimiento);
        this.cuentaBancaria = cuentaBancaria;
        this.nomina = nomina;
    }

    /**
     * Obtiene el número de cuenta bancaria en una cadena de caracteres.
     * @return
     */
    public String getCuentaBancaria() {
        return cuentaBancaria;
    }

    /**
     * Establece el número de cuenta bancaria del profesor.
     * @param cuentaBancaria
     */
    public void setCuentaBancaria(String cuentaBancaria) {
        this.cuentaBancaria = cuentaBancaria;
    }

    /**
     * Obtiene la nómina del profesor en una variable double.
     * @return
     */
    public double getNomina() {
        return nomina;
    }

    /**
     * Establece la nómina del profesor.
     * @param nomina
     */
    public void setNomina(double nomina) {
        this.nomina = nomina;
    }

    /**
     * Imprime la información del profesor.
     */
    public void imprimirProfesor () {
        String imprimir = "Nombre: "+ super.getNombre() + "\nNómina: "  + getNomina()+ "\nCuenta: " + getCuentaBancaria() + "\nFecha nac: " + super.getFechaNacimiento() + "\nDNI: "+ super.getDni();
        JOptionPane.showMessageDialog(null, imprimir);
    }
}
