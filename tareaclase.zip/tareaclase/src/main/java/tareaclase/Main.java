package tareaclase;
import javax.swing.JOptionPane;

public class Main {

    /**
     * Crea un array de profesores.
     * @return
     */
    public static Profesor[] crearArrayProfs () {
        Profesor profesores[] = new Profesor[10];
        return profesores;
    }

    /**
     * Crea un array de alumnos.
     * @return
     */
    public static Alumno[] crearArrayAlu () {
        Alumno alumnos[] = new Alumno[10];
        return alumnos;
    }

    /**
     * Menú principal del programa que introduce y muestra profs. y alumnos.
     * @param profesores
     * @param alumnos
     * @throws Exception
     */
    public static void menu (Profesor [] profesores, Alumno [] alumnos) throws Exception{
        int opcion = 0;
        int contadorProfesores = 0;
        int contadorAlumnos = 0;
        String [] opciones = {"Introducir profesor", "Introducir alumno", "Imprimir profesores", "Imprimir alumnos", "Salir"}; //Array de cadenas de caracteres con las opciones para usar un OptionDialog de JOptionPane.
        while (opcion !=4) {
            opcion = JOptionPane.showOptionDialog(null, "Elija una opción", "Clases",JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, null); //OptionDialog con un entero asigna valores desde el 0 hasta el número de botones creados menos uno.
            switch (opcion) { 
                case 0:
                    if (contadorProfesores<=profesores.length) {
                        profesores[contadorProfesores] = new Profesor (); //Inicializa un profesor con el constructor vacío para introducir uno a uno los datos.
                        profesores[contadorProfesores].setNombre(JOptionPane.showInputDialog(null, "Ingrese el nombre del profesor"));
                        profesores[contadorProfesores].setDni(JOptionPane.showInputDialog(null, "Ingrese el DNI del profesor"));
                        profesores[contadorProfesores].setCuentaBancaria(JOptionPane.showInputDialog(null, "Ingrese la cuenta bancaria del profesor"));
                        profesores[contadorProfesores].setNomina(Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese la nómina del profesor")));
                        profesores[contadorProfesores].setFechaNacimiento(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la fecha de nacimiento: ingrese el año.")), Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la fecha de nacimiento: ingrese el mes (en números).")), Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la fecha de nacimiento: ingrese el día."))); //El método setFechaNacimiento recibe tres valores de tipo entero para crear un objeto de la clase LocalDate. Los datos recogidos por ShowInputDialog siempre se recogen en una cadena de caracteres, por lo que debe usarse Integer.parseInt(String) 
                        contadorProfesores++; //Aumenta el contador de profesores hasta llegar al máximo.
                    } else { 
                        JOptionPane.showMessageDialog(null, "Se ha alcanzado el máximo de profesores.", "Máximo alcanzado.", JOptionPane.ERROR_MESSAGE);
                    }
                    break;  
                case 1:
                    if (contadorAlumnos<=alumnos.length){
                    alumnos[contadorAlumnos] = new Alumno(); //Inicializa un alumno con el constructor vacío para introducir uno a uno los datos.
                    alumnos[contadorAlumnos].setNombre(JOptionPane.showInputDialog(null, "Ingrese el nombre del alumno"));
                    alumnos[contadorAlumnos].setDni(JOptionPane.showInputDialog(null, "Ingrese el DNI del alumno"));
                    alumnos[contadorAlumnos].setFechaNacimiento(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la fecha de nacimiento: ingrese el año.")), Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la fecha de nacimiento: ingrese el mes (en números).")), Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la fecha de nacimiento: ingrese el día.")));
                    contadorAlumnos++; //Aumenta el contador de alumnos hasta llegar al máximo.
                    } else {
                        JOptionPane.showMessageDialog(null, "Se ha alcanzado el máximo de alumnos.", "Máximo alcanzado.", JOptionPane.ERROR_MESSAGE);
                    }
                    break;
                case 2:
                    for(int i=0;i<contadorProfesores;i++){
                        profesores[i].imprimirProfesor();
                    }
                    break;
                case 3: 
                    for(int i=0;i<contadorAlumnos;i++){
                        alumnos[i].imprimirAlumno();
                    }
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Saliendo...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                    break;
            }
        }
    }
    /** Método principal del programa.
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        Profesor [] Profesores = crearArrayProfs();
        Alumno [] Alumnos = crearArrayAlu();
        menu(Profesores, Alumnos);
    }
}